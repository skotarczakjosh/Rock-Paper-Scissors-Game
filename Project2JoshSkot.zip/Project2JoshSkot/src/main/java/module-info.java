module com.example.project2joshskot {
    requires javafx.controls;
    requires javafx.fxml;
            
                            
    opens com.example.project2joshskot to javafx.fxml;
    exports com.example.project2joshskot;
}